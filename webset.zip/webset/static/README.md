This is a assignment 1 and 2.（Modified version）
